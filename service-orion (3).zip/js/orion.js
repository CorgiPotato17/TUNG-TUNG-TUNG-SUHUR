/* ============================================================
   orion.js — Orion, the on-shift assistant.

   This runs entirely client-side: it reads the live restaurant
   state (orders, stock, tables, staff) and reasons over it with
   plain rules, so it works with zero setup and no API key.

   Swap in a real model: replace answerQuestion() with a call to
   /v1/messages and pass buildContextSummary(state) as context.
   See README "Connecting a real AI model".
   ============================================================ */

const Orion = (function () {

  /* ---------- core analysis: turns raw state into findings ---------- */

  function analyze(state) {
    const findings = [];

    // 1. Stock below par, weighted by how busy the item is right now
    const activeCounts = countActiveItems(state);
    state.menu.forEach(item => {
      if (item.par === 0) return;
      const pct = item.onHand / item.par;
      if (pct <= 0.35) {
        const inPlay = activeCounts[item.name] || 0;
        findings.push({
          type: "stock",
          severity: pct <= 0.2 ? "high" : "medium",
          text: `${item.name} is at ${item.onHand} of a ${item.par} par (${item.station}).` +
                (inPlay > 0 ? ` ${inPlay} on the floor right now still need it.` : ` Nothing currently on the floor needs it, but reorder before tomorrow's prep.`),
          action: `86 watch: ${item.name}`
        });
      }
    });

    // 2. Tickets sitting a long time since fired
    state.orders.filter(o => o.status === "fired").forEach(o => {
      const mins = Math.round((Date.now() - o.firedAt) / 60000);
      if (mins >= 12) {
        findings.push({
          type: "ticket",
          severity: mins >= 20 ? "high" : "medium",
          text: `Table ${o.table} has been fired for ${mins} min (server ${o.server}). Worth a check-in at the pass.`,
          action: `Check table ${o.table}`
        });
      }
    });

    // 3. Checks sitting dropped a long time (table not turning)
    state.orders.filter(o => o.status === "check").forEach(o => {
      const mins = Math.round((Date.now() - o.firedAt) / 60000);
      if (mins >= 30) {
        findings.push({
          type: "turn",
          severity: "low",
          text: `Table ${o.table}'s check has been down for ${mins} min. If tonight's busy, a table touch could speed the turn.`,
          action: `Nudge table ${o.table}`
        });
      }
    });

    // 4. Floor load vs staff on section
    const seatedOrFired = state.tables.filter(t => t.status !== "open").length;
    const openTables = state.tables.length - seatedOrFired;
    if (openTables <= 2 && seatedOrFired >= state.tables.length - 2) {
      findings.push({
        type: "floor",
        severity: "medium",
        text: `Only ${openTables} table${openTables === 1 ? "" : "s"} open across the room. If the wait grows, consider a hold list or calling in an extra runner.`,
        action: `Review floor`
      });
    }

    // 5. Best seller vs low stock collision (a dish selling well but running out)
    const best = bestSellers(state, 3);
    best.forEach(({ name, count }) => {
      const item = state.menu.find(m => m.name === name);
      if (item && item.par > 0 && item.onHand / item.par <= 0.4) {
        findings.push({
          type: "collision",
          severity: "high",
          text: `${name} is tonight's #${best.indexOf(best.find(b => b.name === name)) + 1} seller and also low on hand (${item.onHand} left). Consider a table-side heads-up to servers before you 86 it mid-service.`,
          action: `Alert servers: ${name}`
        });
      }
    });

    // sort: high severity first
    const order = { high: 0, medium: 1, low: 2 };
    findings.sort((a, b) => order[a.severity] - order[b.severity]);
    return findings;
  }

  function countActiveItems(state) {
    const counts = {};
    state.orders.filter(o => o.status !== "check").forEach(o => {
      o.items.forEach(raw => {
        const { name, qty } = parseItem(raw);
        counts[name] = (counts[name] || 0) + qty;
      });
    });
    return counts;
  }

  function parseItem(raw) {
    const m = raw.match(/^(.*?)(?:\s*x(\d+))?$/i);
    return { name: (m[1] || raw).trim(), qty: m[2] ? parseInt(m[2], 10) : 1 };
  }

  function bestSellers(state, n) {
    const counts = {};
    state.orders.forEach(o => {
      o.items.forEach(raw => {
        const { name, qty } = parseItem(raw);
        counts[name] = (counts[name] || 0) + qty;
      });
    });
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, n);
  }

  /* ---------- question answering ---------- */

  function answerQuestion(state, question) {
    const q = question.toLowerCase().trim();

    if (/\b(low|out|stock|86|reorder|running)\b/.test(q)) {
      const low = state.menu.filter(m => m.par > 0 && m.onHand / m.par <= 0.35)
        .sort((a, b) => (a.onHand / a.par) - (b.onHand / b.par));
      if (!low.length) return "Everything's above a safe par right now — no reorders needed.";
      return "Running low: " + low.map(m => `${m.name} (${m.onHand}/${m.par})`).join(", ") + ".";
    }

    if (/\b(best|top|selling|popular)\b/.test(q)) {
      const best = bestSellers(state, 5);
      if (!best.length) return "No tickets in yet tonight to rank.";
      return "Tonight's ranking so far: " + best.map((b, i) => `${i + 1}. ${b.name} (${b.count})`).join(", ") + ".";
    }

    if (/\b(table|floor|section|open|seated)\b/.test(q)) {
      const open = state.tables.filter(t => t.status === "open").length;
      const seated = state.tables.filter(t => t.status === "seated").length;
      const fired = state.tables.filter(t => t.status === "fired").length;
      const check = state.tables.filter(t => t.status === "check").length;
      return `Floor right now: ${open} open, ${seated} seated, ${fired} fired, ${check} with a check down. ${state.tables.length} tables total.`;
    }

    if (/\b(staff|crew|schedule|who'?s on|working)\b/.test(q)) {
      const on = state.staff.map(s => `${s.name} (${s.role}, ${s.shift})`).join(", ");
      return `On the schedule tonight: ${on}.`;
    }

    if (/\b(revenue|sales|total|made|covers)\b/.test(q)) {
      const total = state.orders.reduce((sum, o) => sum + o.total, 0);
      const covers = state.tables.filter(t => t.status !== "open").length;
      return `So far tonight: $${total} across open and closed tickets, roughly ${covers} tables turned or seated.`;
    }

    if (/\b(slow|wait|long|check.?in|stuck)\b/.test(q)) {
      const stale = state.orders.filter(o => o.status === "fired" && (Date.now() - o.firedAt) / 60000 >= 12);
      if (!stale.length) return "Nothing's dragging — all fired tickets are moving at a normal pace.";
      return "Worth a look: " + stale.map(o => `table ${o.table} (${Math.round((Date.now() - o.firedAt) / 60000)} min)`).join(", ") + ".";
    }

    if (/\b(hi|hello|hey)\b/.test(q)) {
      return "Hey — I'm reading the floor, the pass, and the walk-in as the shift moves. Ask me about stock, tickets, tables, or who's on tonight.";
    }

    // fallback: surface the single most urgent finding
    const findings = analyze(state);
    if (findings.length) {
      return `Here's what I'd flag first: ${findings[0].text}`;
    }
    return "Service is clean right now — no flags on stock, tickets, or the floor.";
  }

  /* ---------- quick-chip prompts shown in the drawer ---------- */
  const CHIPS = [
    "What's running low?",
    "What's selling best tonight?",
    "Any tickets dragging?",
    "How's the floor look?",
    "Who's on shift?"
  ];

  return { analyze, bestSellers, answerQuestion, CHIPS };
})();
