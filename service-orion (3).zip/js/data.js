/* ============================================================
   data.js — seed data + tiny persistence layer (localStorage)
   Everything here is demo data for a fictional restaurant
   called "Service". Swap freely for a real backend later —
   see README "Connecting real data" section.
   ============================================================ */

const STORE_KEY = "orion_service_v1";

const SEED = {
  restaurant: { name: "Service", city: "Palo Alto", covers_target: 180 },

  servers: ["Mara", "Theo", "Priya", "Diego", "Junko"],

  menu: [
    { id: "m1", name: "Duck confit", station: "Hot line", onHand: 14, par: 20, price: 34, category: "Mains" },
    { id: "m2", name: "Burrata & charred grape", station: "Cold pantry", onHand: 6, par: 15, price: 18, category: "Starters" },
    { id: "m3", name: "House sourdough", station: "Bakery", onHand: 22, par: 25, price: 8, category: "Starters" },
    { id: "m4", name: "Grilled octopus", station: "Hot line", onHand: 3, par: 12, price: 29, category: "Mains" },
    { id: "m5", name: "Mushroom risotto", station: "Hot line", onHand: 18, par: 18, price: 26, category: "Mains" },
    { id: "m6", name: "Little gem salad", station: "Cold pantry", onHand: 20, par: 20, price: 15, category: "Starters" },
    { id: "m7", name: "Steak frites", station: "Grill", onHand: 9, par: 20, price: 38, category: "Mains" },
    { id: "m8", name: "Olive oil cake", station: "Pastry", onHand: 11, par: 14, price: 11, category: "Desserts" },
    { id: "m9", name: "Affogato", station: "Pastry", onHand: 25, par: 20, price: 9, category: "Desserts" },
    { id: "m10", name: "Natural wine, glass", station: "Bar", onHand: 40, par: 30, price: 16, category: "Bar" },
    { id: "m11", name: "Negroni", station: "Bar", onHand: 999, par: 0, price: 15, category: "Bar" },
    { id: "m12", name: "Sparkling water", station: "Bar", onHand: 2, par: 24, price: 6, category: "Bar" }
  ],

  tables: [
    { id: "t1", label: "1", seats: 2, status: "seated", server: "Mara" },
    { id: "t2", label: "2", seats: 2, status: "open", server: null },
    { id: "t3", label: "3", seats: 4, status: "fired", server: "Theo" },
    { id: "t4", label: "4", seats: 4, status: "check", server: "Priya" },
    { id: "t5", label: "5", seats: 6, status: "seated", server: "Diego" },
    { id: "t6", label: "6", seats: 2, status: "open", server: null },
    { id: "t7", label: "7", seats: 4, status: "seated", server: "Junko" },
    { id: "t8", label: "8", seats: 4, status: "fired", server: "Mara" },
    { id: "t9", label: "9", seats: 2, status: "open", server: null },
    { id: "t10", label: "10", seats: 8, status: "seated", server: "Theo" },
    { id: "t11", label: "Bar 1", seats: 1, status: "check", server: "Diego" },
    { id: "t12", label: "Bar 2", seats: 1, status: "open", server: null }
  ],

  orders: [
    { id: "o1", table: "3", items: ["Steak frites", "Little gem salad", "Natural wine, glass"], server: "Theo", status: "fired", firedAt: minsAgo(6), total: 69 },
    { id: "o2", table: "5", items: ["Duck confit x2", "Burrata & charred grape", "House sourdough"], server: "Diego", status: "fired", firedAt: minsAgo(14), total: 94 },
    { id: "o3", table: "4", items: ["Mushroom risotto", "Olive oil cake"], server: "Priya", status: "check", firedAt: minsAgo(38), total: 37 },
    { id: "o4", table: "7", items: ["Grilled octopus", "Grilled octopus", "Sparkling water x2"], server: "Junko", status: "fired", firedAt: minsAgo(3), total: 70 },
    { id: "o5", table: "8", items: ["Steak frites", "Steak frites", "Negroni x2"], server: "Mara", status: "fired", firedAt: minsAgo(9), total: 106 },
    { id: "o6", table: "10", items: ["Duck confit x3", "Little gem salad x2", "House sourdough x2"], server: "Theo", status: "seated", firedAt: minsAgo(1), total: 148 },
    { id: "o7", table: "Bar 1", items: ["Burrata & charred grape", "Natural wine, glass x2"], server: "Diego", status: "check", firedAt: minsAgo(51), total: 50 }
  ],

  coversByHour: [
    { hour: "5p", today: 12, lastWeek: 10 },
    { hour: "6p", today: 34, lastWeek: 28 },
    { hour: "7p", today: 58, lastWeek: 61 },
    { hour: "8p", today: 47, lastWeek: 52 },
    { hour: "9p", today: 29, lastWeek: 24 },
    { hour: "10p", today: 11, lastWeek: 9 }
  ],

  staff: [
    { name: "Mara", role: "Server", shift: "4p – close", tables: 3, note: "Section A" },
    { name: "Theo", role: "Server", shift: "4p – close", tables: 3, note: "Section B" },
    { name: "Priya", role: "Server", shift: "5p – 11p", tables: 2, note: "Section C" },
    { name: "Diego", role: "Bartender", shift: "4p – close", tables: 0, note: "Bar + Section D" },
    { name: "Junko", role: "Server", shift: "5p – 11p", tables: 2, note: "Section D" },
    { name: "Wes", role: "Chef de cuisine", shift: "2p – close", tables: 0, note: "Hot line" },
    { name: "Ana", role: "Sous chef", shift: "2p – 10p", tables: 0, note: "Grill" },
    { name: "Sam", role: "Host", shift: "4p – 9p", tables: 0, note: "Front door" }
  ]
};

function minsAgo(n) { return Date.now() - n * 60 * 1000; }

/* ---- persistence ---- */
function loadState() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) { /* fall through to seed */ }
  const fresh = structuredClone(SEED);
  saveState(fresh);
  return fresh;
}

function saveState(state) {
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
}

function resetState() {
  localStorage.removeItem(STORE_KEY);
  return loadState();
}
